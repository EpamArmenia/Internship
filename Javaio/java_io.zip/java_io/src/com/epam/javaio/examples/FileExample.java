package com.epam.javaio.examples;

import java.io.File;
import java.io.IOException;

public class FileExample {
	
	public static void main(String[] args) {
		File file = new File("./Files/aaa");
		
		file.mkdir();
		
		System.out.println(file.exists());
		//file.getParentFile().mkdirs();
		
		try {
			//file.createNewFile();
			System.out.println(file.getCanonicalPath());
		} catch (IOException e) {			
			e.printStackTrace();
		}		
		
	}

}

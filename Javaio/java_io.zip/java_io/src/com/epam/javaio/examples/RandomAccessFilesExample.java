package com.epam.javaio.examples;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFilesExample {
	
	public static void main(String[] args) {
		RandomAccessFile randomAccessFile = null;
		
		try {
			randomAccessFile = new RandomAccessFile("./Files/ex1.txt", "rw");
			randomAccessFile.seek(3);
			
			System.out.println(randomAccessFile.readLine());
			
			randomAccessFile.seek(0);
			System.out.println(randomAccessFile.readLine());
			
			randomAccessFile.seek(randomAccessFile.length());
			
			randomAccessFile.writeBytes("new text");
			
			
		} catch (IOException ex) {			
			ex.printStackTrace();
		} finally {
			
			try {
				randomAccessFile.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
			
		}
		
		
	}

}

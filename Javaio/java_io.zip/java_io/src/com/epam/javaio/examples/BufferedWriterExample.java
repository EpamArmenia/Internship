package com.epam.javaio.examples;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterExample {

	public static void main(String[] args) {		
		File file = new File("./Files/ex1.txt");	
		BufferedWriter bufferedWriter = null;
		
		//"file.separator"
		//"line.separator"
		try {			
			bufferedWriter = new BufferedWriter(new FileWriter(file));
			
			bufferedWriter.write("Buffered Writer Example");
			bufferedWriter.newLine();
			bufferedWriter.write("Second line");
			
		} catch (IOException e) {			
			e.printStackTrace();
		} finally {
			try {
				bufferedWriter.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}

	}

}

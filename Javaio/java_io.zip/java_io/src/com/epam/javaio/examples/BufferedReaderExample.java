package com.epam.javaio.examples;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class BufferedReaderExample {

	public static void main(String[] args) {
		File file = new File("./Files/ex1.txt");	
		//InputStream inputStream = new FileInputStream(file);
		//Reader reader = new InputStreamReader(inputStream);
		BufferedReader bufferedReader = null;
		
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			String line;
			
			while ((line = bufferedReader.readLine()) != null) {
				System.out.println(line);			
			}
		} catch(IOException ex) {
			ex.printStackTrace();
		} finally {
			
			try {
				bufferedReader.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
			
		}
		
		
		
		

	}

}

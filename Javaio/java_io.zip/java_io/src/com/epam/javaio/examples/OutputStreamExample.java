package com.epam.javaio.examples;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class OutputStreamExample {

	public static void main(String[] args) {
		File file = new File("./Files/aaa.aaa");
		
		OutputStream outputStream = null;
		Writer writer = null;
		
		try {
			file.createNewFile();
			outputStream = new FileOutputStream(file);	
			writer = new OutputStreamWriter(outputStream);
			
			String data = "test data";
			//outputStream.write(data.getBytes());
			writer.write(data);
			
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			
			try {
				writer.close();
				outputStream.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
			
		}
		
	}

}

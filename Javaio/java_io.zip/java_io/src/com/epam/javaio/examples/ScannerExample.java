package com.epam.javaio.examples;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ScannerExample {

	public static void main(String[] args) {
		Scanner scanner = null;
		
		try {
			scanner = new Scanner(new File("./Files/ex1.txt"));
			scanner.useDelimiter(",");
			
			while (scanner.hasNext()) {
				System.out.println(scanner.next());			
			}
			
		} catch (FileNotFoundException e) {			
			e.printStackTrace();
		} finally {
			scanner.close();
		}
		
	}

}

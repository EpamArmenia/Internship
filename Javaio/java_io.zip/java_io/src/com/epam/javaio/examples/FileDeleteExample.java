package com.epam.javaio.examples;

import java.io.File;

public class FileDeleteExample {

	public static void main(String[] args) {
		File file = new File("./Files/texts");
		delete(file);
	}
	
	private static void delete(File file) {
		if (!file.exists()) {
			return;
		}
		
		if (file.isDirectory()) {
			for (File child : file.listFiles()) {				
				if (child.isDirectory()) {
					delete(child);				
				}
				
				child.delete();				
			}
		}		
		
		file.delete();
	}

}

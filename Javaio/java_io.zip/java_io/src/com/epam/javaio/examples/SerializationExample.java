package com.epam.javaio.examples;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationExample {

	public static void main(String[] args) {
		User user = new User();
		user.setId(1);
		user.setName("Poxos");
		user.setTransientField("It's a transient field");
		
		//ObjectOutputStream objectOutputStream = null;
		ObjectInputStream objectInputStream = null;
		
		try {
			objectInputStream = new ObjectInputStream(new FileInputStream("./Files/user.ser"));
			//objectOutputStream = new ObjectOutputStream(new FileOutputStream("./Files/user.ser"));
			//objectOutputStream.writeObject(user);
			
			User readUser = (User) objectInputStream.readObject();
			System.out.println(readUser);
		} catch (IOException e) {		
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				//objectOutputStream.close();
				objectInputStream.close();
			} catch (IOException e) {			
				e.printStackTrace();
			}
			
		}
		

	}
	
	

}

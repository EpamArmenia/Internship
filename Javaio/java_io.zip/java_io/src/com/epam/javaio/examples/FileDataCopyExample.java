package com.epam.javaio.examples;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class FileDataCopyExample {

	public static void main(String[] args) {
		File file = new File("./Files/ex1.txt");	
		File dest = new File("./Files/ex3.txt");
		
		BufferedReader bufferedReader = null;
		PrintWriter printWriter = null;
		
		try {
			dest.createNewFile();
			bufferedReader = new BufferedReader(new FileReader(file));	
			printWriter = new PrintWriter(dest);
			String line;
			int rows = 0;
			
			while ((line = bufferedReader.readLine()) != null) {
				printWriter.println(line);
				rows++;
			}
			
			System.out.println("copied rows = " + rows);
			
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				bufferedReader.close();				
			} catch (IOException e) {			
				e.printStackTrace();
			}	
			
			printWriter.close();
		}
		
		
		

	}

}

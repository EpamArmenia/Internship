package com.epam.javaio.examples;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class InputStreamExample {

	public static void main(String[] args) {
		File file = new File("./Files/ex1.txt");
		InputStream io = null;
		Reader reader = null;
		
		try {
			io = new FileInputStream(file);
			reader = new InputStreamReader(io);
			
			char[] data = new char[10];
			reader.read(data);
			//int data;
			//byte[] data = new byte[10];
			//io.read(data);
			/*
			while ((data = io.read()) != -1) {
				System.out.print((char) data);				
			}
			*/
			
			for (char c : data) {				
				if (c != 0) 
					System.out.print(c);
			}
			
			
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			
			try {
				io.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
			
		}
		
		
	}

}

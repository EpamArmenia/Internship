package com.epam.training;

import java.util.Arrays;

public abstract class Test {
	int arrayCreator(int size)[] {
		int[] array = new int[size];
		for (int i = 0; i < array.length; i++) {
			array[i] = i;
		}

		System.out.println(array[array.length]);
		return array;
	}

	static int[][] matrixCreator(int width, int height) {
		int[][] array = new int[height][width];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j] = i + j;
			}
		}

		return array;
	}

	public static void main(String[] args) {
		int[] array = { 2, 4, 6, 8, 10 };
		for (int i : array) {
			System.out.println("i = " + i);
		}

		String[][] text = new String[][] { 
			{ "ab", "cd" },
			{ "ij", "kl" },
			{ "xy", "z" }
		};
		for (String[] strings : text) {
			for (String string : strings) {
				System.out.print(string + "  ");
			}
			
			System.out.println();
		}

		// int[]dd = {};
		// for (int i : dd) {
		// System.out.println(i);
		// }
		// System.out.println("test");
		// int[][] p = matrixCreator(5, 0);
		// for (int[] is : p) {
		// System.out.println(Arrays.toString(is));
		// }
		//
		// int[][] a = new int[5][];
		// int[] array1;
		// String[][] text[][];
		// text = new String[3][2][][];
		// double[] numbers[];
		// Object[] objs;// No new Object is created
		//
		// int[] array = { 1, 2, 3, 4, 5 };
		// System.out.println(text.length);
		// System.out.println(text[2].length);

		// System.out.println(array[array.length]);
		// text = new String[] { "ab", "bc", "ac" };
		// objs = new Object[] {};// Empty array

		// numbers = new double[];// Will not compile; needs a size
		// array = new int[5];
		// array = new int[] { 1, 2 };
		// // text = new String[20];
		// for (int i = 0; i < 5; System.out.println("Count is: " + i), i++)
		// ;

		// for (;;) {
		// System.out.println("Is this a vlid loop?");
		// }

		for (int i = 0, j = 10; i < 10 && j > 0; i++, j--) {
			System.out.println("i is " + i + " j is " + j);
		}

		for (int i = 0; i < 5; i++) {
			if (i == 3) {
				System.out.println("continue!");
				continue;
			}
			System.out.println("i = " + i);
		}

		int i = 0;
		while (i < 5) {
			if (i == 3) {
				System.out.println("break!");
				break;
			}
			System.out.println("i = " + i);
			i++;
		}

		int b = 3;
		for (int a1 = 1; b != 1; System.out.println("iterate")) {
			b = b - a1;
		}

		// int i = 0;
		// while (i < 10) {
		// System.out.println("Infinite loop, iteration: " + i);
		// if (i == 5)
		// continue;
		//
		// i++;
		// }
	}
}

package com.epam.training.loops;

public class WhileLoopSample {

	public static void main(String[] args) {
		bitCounter(999);
	}

	public static void bitCounter(int positiveNumber) {
		if (positiveNumber > 0) {
			int bits = 1;
			while (positiveNumber > 1) {
				positiveNumber /= 2;
				bits++;
			}

			System.out.println("The smallest amount of bits required to hold the number is: " + bits);

		} else {
			System.out.println("Sorry, this method counts bits only for positive numbers.");
		}
	}
}

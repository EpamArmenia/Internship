package com.epam.training.arrays;

public class MultyDimensionalArraySample {

	public static void main(String[] args) {

		char[][] alphabet = { { 'A' }, { 'B', 'C' }, { 'D' }, { 'E', 'F' }, { 'G' }, { 'H', 'I' }, { 'J' },
				{ 'K', 'L' }, { 'M' }, { 'N', 'O' }, { 'P' }, { 'Q', 'R' }, { 'S' }, { 'T', 'U' }, { 'V' },
				{ 'W', 'X' }, { 'Y' }, { 'Z', 'A' } };

		for (int i = 1; i <= 10; i++) {
			for (int j = 0; j < alphabet[i - 1].length; j++) {
				System.out.print(alphabet[i - 1][j] + "  ");
			}

			System.out.println();
		}
	}
}

package com.epam.training.arrays;

import java.util.Arrays;

public class EnhancedForLoopSample {

	public static void main(String[] args) {

		char[][] alphabet = { { 'A' }, { 'B', 'C' }, { 'D' }, { 'E', 'F' }, { 'G' }, { 'H', 'I' }, { 'J' },
				{ 'K', 'L' }, { 'M' }, { 'N', 'O' }, { 'P' }, { 'Q', 'R' }, { 'S' }, { 'T', 'U' }, { 'V' },
				{ 'W', 'X' }, { 'Y' }, { 'Z', 'A' } };

		for (char[] cs : alphabet) {
			System.out.println(Arrays.toString(cs));
		}
	}
}

package com.epam.training;

public abstract class Test {

	public static void main(String[] args) {
		bitCounter(999);
	}

	public static void bitCounter(int positiveNumber) {
		if (positiveNumber < 0) {
			System.out.println("Sorry, this method counts bits only for positive numbers.");
			return;
		}

		if (positiveNumber < 2)
			System.out.println("The smallest amount of bits required to hold the number is 1");
		else if (positiveNumber < 4)
			System.out.println("The smallest amount of bits required to hold the number is 2");
		else if (positiveNumber < 8)
			System.out.println("The smallest amount of bits required to hold the number is 3");
		else if (positiveNumber < 16)
			System.out.println("The smallest amount of bits required to hold the number is 4");
		else if (positiveNumber < 32)
			System.out.println("The smallest amount of bits required to hold the number is 5");
		else if (positiveNumber < 64)
			System.out.println("The smallest amount of bits required to hold the number is 6");
		else if (positiveNumber < 128)
			System.out.println("The smallest amount of bits required to hold the number is 7");
		else if (positiveNumber < 256)
			System.out.println("The smallest amount of bits required to hold the number is 8");
		else if (positiveNumber < 512)
			System.out.println("The smallest amount of bits required to hold the number is 9");
		else if (positiveNumber < 1024)
			System.out.println("The smallest amount of bits required to hold the number is 10");
		else if (positiveNumber < 2048)
			System.out.println("The smallest amount of bits required to hold the number is 11");
		else if (positiveNumber < 4096)
			System.out.println("The smallest amount of bits required to hold the number is 12");
		else if (positiveNumber < 8192)
			System.out.println("The smallest amount of bits required to hold the number is 13");
		else if (positiveNumber < 16384)
			System.out.println("The smallest amount of bits required to hold the number is 14");
		else if (positiveNumber < 32768)
			System.out.println("The smallest amount of bits required to hold the number is 15");
		else if (positiveNumber < 65536)
			System.out.println("The smallest amount of bits required to hold the number is 16");
		else if (positiveNumber < 131072)
			System.out.println("The smallest amount of bits required to hold the number is 17");
		else if (positiveNumber < 262144)
			System.out.println("The smallest amount of bits required to hold the number is 18");
		else if (positiveNumber < 524288)
			System.out.println("The smallest amount of bits required to hold the number is 19");
		else if (positiveNumber < 1048576)
			System.out.println("The smallest amount of bits required to hold the number is 20");
		else if (positiveNumber < 2097152)
			System.out.println("The smallest amount of bits required to hold the number is 21");
		else if (positiveNumber < 4194304)
			System.out.println("The smallest amount of bits required to hold the number is 22");
		else if (positiveNumber < 8388608)
			System.out.println("The smallest amount of bits required to hold the number is 23");
		else if (positiveNumber < 16777216)
			System.out.println("The smallest amount of bits required to hold the number is 24");
		else if (positiveNumber < 33554432)
			System.out.println("The smallest amount of bits required to hold the number is 25");
		else if (positiveNumber < 67108864)
			System.out.println("The smallest amount of bits required to hold the number is 26");
		else if (positiveNumber < 134217728)
			System.out.println("The smallest amount of bits required to hold the number is 27");
		else if (positiveNumber < 268435456)
			System.out.println("The smallest amount of bits required to hold the number is 28");
		else if (positiveNumber < 536870912)
			System.out.println("The smallest amount of bits required to hold the number is 29");
		else if (positiveNumber < 1073741824)
			System.out.println("The smallest amount of bits required to hold the number is 30");
		else // positiveNumber <= Integer.MAX_VALUE 2,147,483,647
			System.out.println("The smallest amount of bits required to hold the number is 31");
	}
}

package com.epam.training.loops;

public class LabledBreakAndContinue {

	public static void main(String[] args) {
		findNextPrime(999);
	}

	public static void findNextPrime(int number) {
		if (number > 3) {
			OUTER: for (int i = number; i <= Integer.MAX_VALUE; i++) {
				int squareRoot = (int) Math.sqrt(i);
				for (int j = 2; j <= squareRoot; j++) {
					if (i % j == 0) {
						continue OUTER;
					}

					if (j == squareRoot) {
						System.out.println("The next prime number is: " + i);
						break OUTER;
					}
				}
			}
		} else {
			System.out.print("Sorry, this method works only for numbers greater than 3.");
		}
	}
}

package com.epam.training.loops;

public class BreakSample {

	public static void main(String[] args) {
		bitCounter(999);
	}

	public static void bitCounter(int positiveNumber) {
		if (positiveNumber > 0) {
			for (int bits = 1; bits < 32; bits++, positiveNumber /= 2) {
				if (positiveNumber < 2) {
					System.out.println("The smallest amount of bits required to hold the number is: " + bits);
					break;
				}
			}
		} else {
			System.out.println("Sorry, this method counts bits only for positive numbers.");
		}
	}
}
